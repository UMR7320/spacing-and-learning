# elm-spa
a way to build single page apps with Elm!


## getting started

```
npx elm-spa init your-project
```

_"Wait– that command didn't work!"_  (you might need the latest [NodeJS](https://nodejs.org/))


## just installing the elm package?

```
elm install ryannhg/elm-spa
```


## want to learn more?

you should check out [elm-spa.dev](https://elm-spa.dev)!

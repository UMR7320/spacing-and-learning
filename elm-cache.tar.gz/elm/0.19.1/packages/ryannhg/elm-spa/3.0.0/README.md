# elm-spa
> a way to build single page apps with Elm!


## it's not done until the docs are great!

So nicer documentation and examples are on the way!

Until then, you can join the conversation on [discourse](https://discourse.elm-lang.org/t/elm-spa-a-tool-for-building-single-page-apps/4597/27), or start a conversation in a Github issue.

(_Please, no PRs for now. They're tricky to merge with the constant design changes!_)


## local development

```
npm start
```
